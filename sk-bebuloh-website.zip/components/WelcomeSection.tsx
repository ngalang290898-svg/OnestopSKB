export default function WelcomeSection() {
  return (
    <section className="py-16 bg-gray-100 text-center">
      <h3 className="text-2xl font-bold mb-2">Welcome Message</h3>
      <p>(Headmaster message or school values introduction)</p>
    </section>
  );
}