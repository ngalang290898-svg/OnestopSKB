export default function HeroSection() {
  return (
    <section className="bg-deepSeek text-white py-20 text-center">
      <h2 className="text-3xl font-heading mb-4">Welcome to SK Bebuloh</h2>
      <p className="max-w-xl mx-auto">Inspiring education through tradition and technology.</p>
    </section>
  );
}