'use client';
import Link from 'next/link';
import LanguageToggle from './LanguageToggle';

export default function Navbar() {
  return (
    <nav className="bg-deepSeek text-white p-4 flex justify-between items-center">
      <div className="text-xl font-heading">SK Bebuloh</div>
      <ul className="flex space-x-4">
        <li><Link href="/">Home</Link></li>
        <li><Link href="/about">About</Link></li>
        <li><Link href="/staff">Staff</Link></li>
        <li><Link href="/one-stop">One-Stop</Link></li>
        <li><Link href="/achievements">Achievements</Link></li>
        <li><Link href="/contact">Contact</Link></li>
      </ul>
      <LanguageToggle />
    </nav>
  );
}