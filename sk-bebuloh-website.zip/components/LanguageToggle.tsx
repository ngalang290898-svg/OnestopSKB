'use client';
import { useState } from 'react';

export default function LanguageToggle() {
  const [lang, setLang] = useState('en');
  return (
    <button onClick={() => setLang(lang === 'en' ? 'ms' : 'en')} className="text-sm border px-2 py-1 rounded">
      {lang === 'en' ? 'English' : 'Bahasa Melayu'}
    </button>
  );
}