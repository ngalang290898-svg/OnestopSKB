export default function ContentWrapper({ children }: { children: React.ReactNode }) {
  return <div className="px-4 sm:px-8 md:px-16 py-10">{children}</div>;
}