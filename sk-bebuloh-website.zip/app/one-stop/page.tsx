import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function OneStopPage() {
  return (
    <ContentWrapper>
      <PageTitle title="One-Stop Centre" />
      <p className="text-gray-700">(Resources will appear here.)</p>
    </ContentWrapper>
  );
}