import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function AboutPage() {
  return (
    <ContentWrapper>
      <PageTitle title="About Us" />
      <p className="text-gray-700">(About page content goes here…)</p>
    </ContentWrapper>
  );
}