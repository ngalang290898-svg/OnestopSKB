export default function AuthPage() {
  return (
    <div className="py-20 text-center">
      <h2 className="text-2xl font-bold mb-4">Login</h2>
      <p>(Auth form UI goes here.)</p>
    </div>
  );
}