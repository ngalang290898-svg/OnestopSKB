import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function StaffPage() {
  return (
    <ContentWrapper>
      <PageTitle title="Staff Directory" />
      <p className="text-gray-700">(Staff list will appear here.)</p>
    </ContentWrapper>
  );
}