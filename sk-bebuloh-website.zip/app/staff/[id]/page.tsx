import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function StaffProfile() {
  return (
    <ContentWrapper>
      <PageTitle title="Staff Profile" />
      <p className="text-gray-700">(Individual staff details will appear here.)</p>
    </ContentWrapper>
  );
}