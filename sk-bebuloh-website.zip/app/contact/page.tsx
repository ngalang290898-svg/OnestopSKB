import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function ContactPage() {
  return (
    <ContentWrapper>
      <PageTitle title="Contact Us" />
      <p className="text-gray-700">(Contact form and map goes here.)</p>
    </ContentWrapper>
  );
}