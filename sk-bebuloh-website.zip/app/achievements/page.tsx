import PageTitle from '@/components/PageTitle';
import ContentWrapper from '@/components/ContentWrapper';

export default function AchievementsPage() {
  return (
    <ContentWrapper>
      <PageTitle title="Achievements" />
      <p className="text-gray-700">(Achievement cards or timeline goes here.)</p>
    </ContentWrapper>
  );
}