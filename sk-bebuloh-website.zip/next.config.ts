const nextConfig = {
  experimental: {
    appDir: true
  },
  i18n: {
    locales: ['en', 'ms'],
    defaultLocale: 'en'
  }
};
export default nextConfig;